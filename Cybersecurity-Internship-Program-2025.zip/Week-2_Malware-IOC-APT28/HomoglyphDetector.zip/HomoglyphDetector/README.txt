Homoglyph Detector Tool
========================

This tool detects homoglyph characters in URLs (e.g., Cyrillic letters that look like Latin ones) 
and converts them to a normalized and shortest safe ASCII version.

Usage:
------

1. Install Python 3.x (https://www.python.org/downloads/)
2. Open terminal/command prompt
3. Navigate to this folder:
   cd HomoglyphDetector
4. Install required packages:
   pip install -r requirements.txt
5. Run the script with a URL:
   python homoglyph_detector.py https://exаmple.com
   (Notice the 'а' here is Cyrillic, not Latin.)

Output:
-------
- Alerts if suspicious characters are found.
- Shows a normalized version of the URL.
- Displays the shortest safe ASCII version (Punycode if necessary).

Example:
--------
$ python homoglyph_detector.py https://раураl.com
[!] Suspicious homoglyph characters detected: р а у а l
[i] Normalized URL: https://paypal.com
[i] Shortest ASCII version: https://xn--pypal-4ve.com
