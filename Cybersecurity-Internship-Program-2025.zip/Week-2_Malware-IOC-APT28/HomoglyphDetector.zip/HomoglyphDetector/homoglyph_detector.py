import unicodedata
import idna
import sys

# Common homoglyph map (basic, can be expanded)
HOMOGLYPH_MAP = {
    'а': 'a',  # Cyrillic small a -> Latin a
    'е': 'e',  # Cyrillic small e -> Latin e
    'о': 'o',  # Cyrillic small o -> Latin o
    'і': 'i',  # Cyrillic small i -> Latin i
    'ѕ': 's',  # Cyrillic small s -> Latin s
    'р': 'p',  # Cyrillic small p -> Latin p
    'ӏ': 'l',  # Cyrillic small l -> Latin l
}

def normalize_url(url):
    """Normalize suspicious characters in URL"""
    normalized = ""
    for char in url:
        normalized += HOMOGLYPH_MAP.get(char, char)
    return normalized

def detect_homoglyph(url):
    """Check if the URL contains homoglyphs"""
    suspicious_chars = [char for char in url if char in HOMOGLYPH_MAP]
    return suspicious_chars

def shortest_ascii(url):
    """Convert to shortest safe ASCII (Punycode if needed)"""
    try:
        # Extract domain
        if "://" in url:
            protocol, rest = url.split("://", 1)
        else:
            protocol, rest = "http", url
        domain, *path = rest.split("/", 1)
        ascii_domain = idna.encode(domain).decode("ascii")
        ascii_url = protocol + "://" + ascii_domain
        if path:
            ascii_url += "/" + path[0]
        return ascii_url
    except Exception as e:
        return f"Error converting to ASCII: {e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python homoglyph_detector.py <url>")
        sys.exit(1)
    
    input_url = sys.argv[1]
    
    # Detect homoglyphs
    suspicious = detect_homoglyph(input_url)
    if suspicious:
        print(f"[!] Suspicious homoglyph characters detected: {' '.join(suspicious)}")
    else:
        print("[+] No homoglyph characters detected.")
    
    # Normalized form
    normalized_url = normalize_url(input_url)
    print(f"[i] Normalized URL: {normalized_url}")
    
    # Shortest ASCII
    ascii_version = shortest_ascii(normalized_url)
    print(f"[i] Shortest ASCII version: {ascii_version}")
